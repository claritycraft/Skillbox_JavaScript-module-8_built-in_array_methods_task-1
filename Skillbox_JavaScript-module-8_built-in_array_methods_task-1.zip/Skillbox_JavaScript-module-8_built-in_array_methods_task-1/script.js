const countVowels = (word) => {
  // Определяем массив гласных букв русского алфавита
  const vowels = ["а", "е", "ё", "и", "о", "у", "ы", "э", "ю", "я"];

  // Приводим слово к нижнему регистру для удобства сравнения
  const lowerCaseWord = word.toLowerCase();

  // Используем метод filter() для фильтрации гласных букв
  const vowelCount = lowerCaseWord
    .split("")
    .filter((letter) => vowels.includes(letter)).length;

  // Возвращаем количество гласных букв
  return vowelCount;
};

// Запрос пользователя для ввода слова
const word = prompt("Введите слово:");
const vowelCount = countVowels(word);
alert(`Количество гласных в слове "${word}": ${vowelCount}`);
